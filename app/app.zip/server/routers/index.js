const KoaRouter = require('koa-router');

const Models = require('../models')



const router = new KoaRouter();


router.get('/', async ctx => {
    const users  = await Models.users.findAll()
    const contents  = await Models.contents.findAll()
     const comments  = await Models.comments.findAll()
     const likes  = await Models.likes.findAll()
    const data = {
        users,
        contents,
        comments,
        likes
    }

    console.log(data)
    ctx.body =data
});


module.exports = router;